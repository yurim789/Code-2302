let count = 0;
const value = document.querySelector("#value");
const btns = document.querySelectorAll(".btn");